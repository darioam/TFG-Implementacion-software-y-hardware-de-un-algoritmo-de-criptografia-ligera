// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of plaintext_0
//        bit 31~0 - plaintext_0[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of plaintext_1
//        bit 31~0 - plaintext_1[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of plaintext_2
//        bit 31~0 - plaintext_2[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of plaintext_3
//        bit 31~0 - plaintext_3[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of plaintext_4
//        bit 31~0 - plaintext_4[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of plaintext_5
//        bit 31~0 - plaintext_5[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of plaintext_6
//        bit 31~0 - plaintext_6[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of plaintext_7
//        bit 31~0 - plaintext_7[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of key
//        bit 31~0 - key[31:0] (Read/Write)
// 0x54 : Data signal of key
//        bit 31~0 - key[63:32] (Read/Write)
// 0x58 : reserved
// 0x5c : Data signal of ciphertext_0
//        bit 31~0 - ciphertext_0[31:0] (Read)
// 0x60 : Control signal of ciphertext_0
//        bit 0  - ciphertext_0_ap_vld (Read/COR)
//        others - reserved
// 0x6c : Data signal of ciphertext_1
//        bit 31~0 - ciphertext_1[31:0] (Read)
// 0x70 : Control signal of ciphertext_1
//        bit 0  - ciphertext_1_ap_vld (Read/COR)
//        others - reserved
// 0x7c : Data signal of ciphertext_2
//        bit 31~0 - ciphertext_2[31:0] (Read)
// 0x80 : Control signal of ciphertext_2
//        bit 0  - ciphertext_2_ap_vld (Read/COR)
//        others - reserved
// 0x8c : Data signal of ciphertext_3
//        bit 31~0 - ciphertext_3[31:0] (Read)
// 0x90 : Control signal of ciphertext_3
//        bit 0  - ciphertext_3_ap_vld (Read/COR)
//        others - reserved
// 0x9c : Data signal of ciphertext_4
//        bit 31~0 - ciphertext_4[31:0] (Read)
// 0xa0 : Control signal of ciphertext_4
//        bit 0  - ciphertext_4_ap_vld (Read/COR)
//        others - reserved
// 0xac : Data signal of ciphertext_5
//        bit 31~0 - ciphertext_5[31:0] (Read)
// 0xb0 : Control signal of ciphertext_5
//        bit 0  - ciphertext_5_ap_vld (Read/COR)
//        others - reserved
// 0xbc : Data signal of ciphertext_6
//        bit 31~0 - ciphertext_6[31:0] (Read)
// 0xc0 : Control signal of ciphertext_6
//        bit 0  - ciphertext_6_ap_vld (Read/COR)
//        others - reserved
// 0xcc : Data signal of ciphertext_7
//        bit 31~0 - ciphertext_7[31:0] (Read)
// 0xd0 : Control signal of ciphertext_7
//        bit 0  - ciphertext_7_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_AP_CTRL           0x00
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_GIE               0x04
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_IER               0x08
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_ISR               0x0c
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_0_DATA  0x10
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_0_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_1_DATA  0x18
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_1_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_2_DATA  0x20
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_2_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_3_DATA  0x28
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_3_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_4_DATA  0x30
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_4_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_5_DATA  0x38
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_5_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_6_DATA  0x40
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_6_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_PLAINTEXT_7_DATA  0x48
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_PLAINTEXT_7_DATA  32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_KEY_DATA          0x50
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_KEY_DATA          64
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_0_DATA 0x5c
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_0_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_0_CTRL 0x60
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_1_DATA 0x6c
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_1_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_1_CTRL 0x70
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_2_DATA 0x7c
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_2_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_2_CTRL 0x80
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_3_DATA 0x8c
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_3_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_3_CTRL 0x90
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_4_DATA 0x9c
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_4_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_4_CTRL 0xa0
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_5_DATA 0xac
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_5_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_5_CTRL 0xb0
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_6_DATA 0xbc
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_6_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_6_CTRL 0xc0
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_7_DATA 0xcc
#define XCIFRADOR_PARALELO_8_CONTROL_BITS_CIPHERTEXT_7_DATA 32
#define XCIFRADOR_PARALELO_8_CONTROL_ADDR_CIPHERTEXT_7_CTRL 0xd0

